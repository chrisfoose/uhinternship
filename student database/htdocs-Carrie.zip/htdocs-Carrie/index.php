<?php include "templates/header.php"; ?>
 <h1>Example Database App</h1>
 <ul>     

     <li>
		<a href="install.php">
			<strong>
				Create Database
			</strong>
		</a> 
	</li>
     <li><a href="create.php"><strong>Create New User</strong></a> </li>
     <li><a href="read.php"><strong>Select a User by Last Name</strong></a> </li>
	   <li><a href="read2.php"><strong>Select a User by City</strong></a> </li>
     <li><a href="update.php"><strong>Update a User</strong></a> </li>
     <li><a href="delete.php"><strong>Delete a User</strong></a> </li>

</ul>
<?php include "templates/footer.php"; ?>